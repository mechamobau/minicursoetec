import React, {Component} from 'react';

import {View} from 'react-native';

class ImageView extends Component {
    static navigationOptions = {
        title: 'Anexo',
    };

    render = () => {
        return <View />;
    };
}

export default ImageView;
