import React, {Component} from 'react';

import {View} from 'react-native';

class Create extends Component {
    static navigationOptions = {
        title: 'Criar TODO',
    };

    render = () => {
        return <View />;
    };
}

export default Create;
