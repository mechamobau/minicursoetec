import React, {Component} from 'react';

import {View} from 'react-native';

class Detail extends Component {
    static navigationOptions = {
        title: 'TODO',
    };

    render = () => {
        return <View />;
    };
}

export default Detail;
