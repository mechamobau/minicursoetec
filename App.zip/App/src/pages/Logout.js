import React, {Component} from 'react';

import {View} from 'react-native';

class Logout extends Component {
    render = () => {
        return <View />;
    };
}

export default Logout;
