import React, {Component} from 'react';

import {View} from 'react-native';

class List extends Component {
    static navigationOptions = {
        title: 'Lista de TODOs',
    };

    render = () => {
        return <View />;
    };
}

export default List;
