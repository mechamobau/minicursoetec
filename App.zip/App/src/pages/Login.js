import React, {Component} from 'react';

import {View} from 'react-native';

class Login extends Component {
    static navigationOptions = {
        title: 'Login',
    };

    render = () => {
        return <View />;
    };
}

export default Login;
